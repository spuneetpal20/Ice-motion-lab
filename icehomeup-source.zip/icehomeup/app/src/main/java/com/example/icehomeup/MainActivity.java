package com.example.icehomeup;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends Activity {
    private int bg = Color.rgb(16,16,24), panel = Color.rgb(30,30,43), text = Color.rgb(245,244,255), muted = Color.rgb(169,166,190), accent = Color.rgb(183,164,255);
    private TextView speedLabel, previewCard, status;
    private SeekBar speed;
    private String preset = "Fluid";
    private int duration = 420;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(bg);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(22),dp(28),dp(22),dp(28)); scroll.addView(root);
        TextView eyebrow = label("MOTION LAB  •  NON-ROOT", 12, accent, true); root.addView(eyebrow);
        TextView title = label("iCE Motion", 32, text, true); title.setPadding(0,dp(8),0,dp(4)); root.addView(title);
        TextView subtitle = label("A safe animation playground for Android", 14, muted, false); root.addView(subtitle);
        space(root,22);
        card(root, "LIVE PREVIEW", "Tap the tile to preview the selected motion.");
        previewCard = label("✦\n\nOPEN / CLOSE", 16, text, true); previewCard.setGravity(Gravity.CENTER); previewCard.setMinHeight(dp(150)); previewCard.setBackground(round(panel, 24)); LinearLayout.LayoutParams cp = params(); cp.topMargin=dp(12); root.addView(previewCard,cp);
        previewCard.setOnClickListener(v -> animatePreview());
        space(root,22);
        card(root,"ANIMATION PRESET","Presets only affect this preview; they do not change protected Samsung system animations.");
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER); String[] names={"Soft","Fluid","Spring"};
        for(String name:names){ Button b=button(name); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(46),1); p.setMargins(dp(3),dp(12),dp(3),0); row.addView(b,p); b.setOnClickListener(v->{preset=name; status.setText("Selected: "+preset); }); } root.addView(row);
        space(root,18);
        speedLabel=label("Preview duration: 420 ms",14,text,true); root.addView(speedLabel);
        speed=new SeekBar(this); speed.setMax(700); speed.setProgress(320); speed.setProgressTintList(android.content.res.ColorStateList.valueOf(accent)); speed.setThumbTintList(android.content.res.ColorStateList.valueOf(accent)); root.addView(speed);
        speed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){ public void onProgressChanged(SeekBar s,int p,boolean u){duration=180+p; speedLabel.setText("Preview duration: "+duration+" ms");} public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){} });
        space(root,14);
        status=label("Selected: Fluid",13,accent,true); root.addView(status);
        space(root,24);
        card(root,"REAL SYSTEM ANIMATIONS","Android does not let ordinary apps replace Samsung's launcher animation engine. For a safer, reversible change, open Developer options and adjust Window animation scale, Transition animation scale, and Animator duration scale.");
        Button settings=button("Open Developer options"); LinearLayout.LayoutParams bp=params(); bp.topMargin=dp(12); root.addView(settings,bp); settings.setOnClickListener(v->{try{startActivity(new android.content.Intent(android.provider.Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS));}catch(Exception e){status.setText("Open Settings → Developer options manually.");}});
        TextView foot=label("No root • No special permissions • No background service",12,muted,false); foot.setPadding(0,dp(22),0,0); root.addView(foot);
        setContentView(scroll);
    }
    private void animatePreview(){ previewCard.setAlpha(0.65f); previewCard.setScaleX(0.88f); previewCard.setScaleY(0.88f); android.view.animation.Interpolator i = preset.equals("Spring") ? new OvershootInterpolator(1.2f) : preset.equals("Soft") ? new DecelerateInterpolator(1.7f) : new AccelerateDecelerateInterpolator(); previewCard.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(duration).setInterpolator(i).start(); }
    private void card(LinearLayout root,String heading,String body){TextView h=label(heading,12,accent,true); root.addView(h); TextView b=label(body,14,muted,false); b.setPadding(0,dp(7),0,0); root.addView(b);}
    private Button button(String s){Button b=new Button(this); b.setText(s); b.setAllCaps(false); b.setTextColor(text); b.setBackground(round(panel,16)); b.setTypeface(Typeface.DEFAULT_BOLD); return b;}
    private TextView label(String s,int size,int color,boolean bold){TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t;}
    private GradientDrawable round(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));d.setStroke(dp(1),Color.rgb(51,49,69));return d;}
    private LinearLayout.LayoutParams params(){return new LinearLayout.LayoutParams(-1,-2);} private void space(LinearLayout l,int h){View v=new View(this);l.addView(v,new LinearLayout.LayoutParams(1,dp(h)));} private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
}
