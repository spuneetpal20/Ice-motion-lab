# iCE Motion Lab (inspired concept)

A minimal no-root Android app for previewing animation presets. It does not modify Samsung's system animation engine. It uses only Android framework APIs and requests no special permissions.

## Build an APK

This project is configured for Android Gradle Plugin 8.10.1, compile SDK 36, Java 21.

- Open the project in Android Studio with Android SDK 36 installed, then build `app` → `assembleDebug`.
- Or push the project to a GitHub repository and run the included **Build Android APK** workflow. Download the `ice-motion-lab-debug-apk` artifact.

The generated debug APK is for testing. This project is not affiliated with Ice Universe or Samsung and does not reproduce proprietary code.
